package com.example.mobilefinalproject;


import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class Signup2Fragment extends Fragment {
    EditText phonenb;

    public Signup2Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_signup2, container, false);
        Button button = (Button) view.findViewById(R.id.button);
        TextView txt =(TextView) view.findViewById(R.id.login) ;

        phonenb =(EditText) view.findViewById(R.id.editText);

//        sendBtn = (Button) view.findViewById(R.id.btnSendSMS);
//        txtphoneNo = (EditText) view.findViewById(R.id.editTextPhoneNo);
//        txtMessage = (EditText) findViewById(R.id.editTextSMS);

//        sendBtn.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View view) {
//                sendSMSMessage();
//            }
//        });

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(phonenb.length()==0){
                    phonenb.setError("Please Enter your number");
                }
                else {
                    sendSMSMessage();

                    Signupinformation nextFrag= new Signupinformation(); getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, nextFrag, "findThisFragment") .addToBackStack(null) .commit();
                }

            }
        });
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });


        return  view;
    }

    protected void sendSMSMessage() {
        Log.i("Send SMS", "");

        String phoneNo = phonenb.getText().toString();
//        String message = txtMessage.getText().toString();

        try {
            String text = "1234";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, text, null, null);
            Toast.makeText(getActivity().getApplicationContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getActivity().getApplicationContext(),
                    "SMS faild, please try again.",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

}
