package com.example.mobilefinalproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Toast;

public class HomeNav extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_nav);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Thank you for using Faster Faster", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                int menuid = destination.getId();
                switch (menuid){
                    case R.id.nav_gallery:
                        Toast.makeText(HomeNav.this,"Welcome to Faster Faster",Toast.LENGTH_SHORT).show();
                        fab.hide();
                        break;

                    case R.id.nav_share:
                        // Create the object of
                        // AlertDialog Builder class
                        AlertDialog.Builder builder = new AlertDialog.Builder(HomeNav.this);
//        builder.setTitle(R.string.app_name);
                        builder.setTitle("Faster Faster");
// set Icon
                        builder.setIcon(R.mipmap.ic_launcher);
//        Set the message show for the Alert time
                        builder.setMessage(" Do you want to exit App? ");

                        // Set Cancelable false
                        // for when the user clicks on the outside
                        // the Dialog Box then it will remain show
                        builder.setCancelable(false);
                        // Set the positive button with yes name
                        // OnClickListener method is use of
                        // DialogInterface interface.

                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // When the user click yes button
                                // then app will close
//                getActivity().finish();
                                Intent i = new Intent(HomeNav.this, MainActivity.class);
                                startActivity(i);
                                Toast.makeText(HomeNav.this,"Logout Successfully",Toast.LENGTH_SHORT).show();

                            }
                        });
                        // Set the Negative button with No name
                        // OnClickListener method is use
                        // of DialogInterface interface.
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // If user click no
                                // then dialog box is canceled.
//                dialog.cancel();
                                Intent i = new Intent(HomeNav.this, HomeNav.class);
                                startActivity(i);


                            }
                        });


                        // Create the Alert dialog
                        AlertDialog alert = builder.create();
                        // Show the Alert Dialog box
                        alert.show();

                        break;
                    default:
                        fab.show();

                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_nav, menu);
        return true;

    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
        public void openclick(View view) {
//        Toast.makeText(HomeNavigation.this,"you tossed destination",Toast.LENGTH_SHORT).show();
        Intent i = new Intent(HomeNav.this, DestinationMapsActivity.class);
        startActivity(i);

    }

}
