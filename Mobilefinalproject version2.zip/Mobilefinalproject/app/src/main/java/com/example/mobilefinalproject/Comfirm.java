package com.example.mobilefinalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

public class Comfirm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comfirm2);


        // Create the object of
        // AlertDialog Builder class
        final AlertDialog.Builder builder = new AlertDialog.Builder(Comfirm.this);
//        builder.setTitle(R.string.app_name);
//        builder.setTitle("SEAT BOOKING");
// set Icon
        builder.setIcon(R.mipmap.ic_launcher);
//        Set the message show for the Alert time
        builder.setMessage("You have successfully booked \nyour seats with Faster Faster");
        // Set Cancelable false
        // for when the user clicks on the outside
        // the Dialog Box then it will remain show
        builder.setCancelable(false);
        // Set the positive button with yes name
        // OnClickListener method is use of
        // DialogInterface interface.

        builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // When the user click yes button
                // then app will close
                Intent i = new Intent(Comfirm.this, HomeNav.class);
                startActivity(i);

            }
        });
        // Set the Negative button with No name
        // OnClickListener method is use
        // of DialogInterface interface.
//        builder.setNegativeButton("RESEND THE CODE", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                // If user click no
//                // then dialog box is canceled.
////                dialog.cancel();
////                builder.setNegativeButtonIcon(R.drawable.ic_arrow);
//
////                Toast.makeText(PaymentActivity.this,"Seat Bookings",Toast.LENGTH_SHORT).show();
//
////                Intent i = new Intent(BookingActivity.this, BookingActivity.class);
////                startActivity(i);
//
//            }
//        });


        // Create the Alert dialog
        AlertDialog alert = builder.create();
        // Show the Alert Dialog box
        alert.show();
    }
}
