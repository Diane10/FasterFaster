package com.example.mobilefinalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

public class UserinfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);
        // Create the object of
        // AlertDialog Builder class
        final AlertDialog.Builder builder = new AlertDialog.Builder(UserinfoActivity.this);
//        builder.setTitle(R.string.app_name);
        builder.setTitle("BUS INFORMATION");
// set Icon
        builder.setIcon(R.mipmap.ic_launcher);
//        Set the message show for the Alert time
        builder.setMessage(" Available Seat: 6 \n Estimated Time : 3 ");
        // Set Cancelable false
        // for when the user clicks on the outside
        // the Dialog Box then it will remain show
        builder.setCancelable(false);
        // Set the positive button with yes name
        // OnClickListener method is use of
        // DialogInterface interface.

//        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                // When the user click yes button
//                // then app will close
//                finish();
//            }
//        });
        // Set the Negative button with No name
        // OnClickListener method is use
        // of DialogInterface interface.
        builder.setNegativeButton("BOOK YOUR SEAT NOW", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // If user click no
                // then dialog box is canceled.
//                dialog.cancel();
//                builder.setNegativeButtonIcon(R.drawable.ic_arrow);

//                Toast.makeText(userinfo.this,"Seat Bookings",Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UserinfoActivity.this, BookingActivity.class);
                startActivity(i);

            }
        });


        // Create the Alert dialog
        AlertDialog alert = builder.create();
        // Show the Alert Dialog box
        alert.show();
    }
}
