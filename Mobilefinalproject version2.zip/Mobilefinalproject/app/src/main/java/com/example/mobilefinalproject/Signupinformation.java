package com.example.mobilefinalproject;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class Signupinformation extends Fragment {
    EditText codes;
    TextView reset;

    public Signupinformation() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signupinformation, container, false);
        Button btn = (Button) view.findViewById(R.id.buttontwo);
        reset = (TextView) view.findViewById(R.id.textView3);
        codes =(EditText) view.findViewById(R.id.editText2);
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(codes.length()==0){
                    codes.setError("Please Enter your Code");
                }
                else {
                    if(codes.getText().toString().equals("1234")){
                        SignupRegistration  x = new SignupRegistration();
                        getActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container, x, "findThisFragment") .addToBackStack(null) .commit();

                    }
                    else {
                        Toast.makeText(getActivity(),"Invalid Code!",Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Signup2Fragment  x = new Signup2Fragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, x, "findThisFragment") .addToBackStack(null) .commit();
            }
        });

        return view;
    }

}
