package com.example.mobilefinalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Payment extends AppCompatActivity {
    EditText mypay;

    EditText input;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment2);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please Enter your phone number to pay money? ");

        input = new EditText(Payment.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        builder.setView(input);
        builder.setNegativeButton("PAY NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                sendSMSMessage();
                Intent my= new Intent(Payment.this, Verification.class);
                    startActivity(my);
//                Toast.makeText(getApplicationContext(), "Text entered is " + input.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();

//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        LayoutInflater inflater = getLayoutInflater();
//        builder.setMessage("Please Enter your phone number to pay money? ");
//        View dialogLayout = inflater.inflate(R.layout.mypaylayout, null);
//        builder.setPositiveButton("PAY NOW", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                sendSMSMessage();
//                    Intent my= new Intent(Payment.this, UserinfoActivity.class);
//                    startActivity(my);
//
//
//
//
//            }
//        });
//
//        builder.setView(dialogLayout);
//
//        builder.show();


    }

//    @android.support.annotation.RequiresApi(api = Build.VERSION_CODES.DONUT)
    protected void sendSMSMessage() {
        Log.i("Send SMS", "");
//        EditText phonenb =(EditText) findViewById(R.id.mypay);


        String phoneNo = input.getText().toString();
//        String message = txtMessage.getText().toString();


        try {
            String text = "1234";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, text, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),
                    "SMS faild, please try again.",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }



}
