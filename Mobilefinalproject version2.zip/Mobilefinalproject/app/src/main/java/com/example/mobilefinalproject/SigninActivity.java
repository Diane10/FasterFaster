package com.example.mobilefinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SigninActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        Signup2Fragment  x = new Signup2Fragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.container,x).commit();
    }
}
