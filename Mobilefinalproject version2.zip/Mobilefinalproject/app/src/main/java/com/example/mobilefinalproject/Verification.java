package com.example.mobilefinalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import static android.graphics.Color.parseColor;

public class Verification extends AppCompatActivity {
    EditText codes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification2);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("With Edit Text");

        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.myverification, null);
        codes =(EditText) findViewById(R.id.mypay);


        builder.setMessage("Please wait for the verfication code to comfirm your payment \n ");
        builder.setPositiveButton("COMFIRM NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
//                Toast.makeText(getApplicationContext(), "Text entered is " + input.getText().toString(), Toast.LENGTH_SHORT).show();
                Intent k = new Intent(Verification.this, Comfirm.class);
                startActivity(k);
            }
        });
        builder.setNegativeButton("RESEND THE CODE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
//                Toast.makeText(getApplicationContext(), "Text entered is " + input.getText().toString(), Toast.LENGTH_SHORT).show();
                Intent HI = new Intent(Verification.this, Payment.class);
                startActivity(HI);
            }
        });
//        builder.show();
        builder.setView(dialogLayout);
        AlertDialog dialog = builder.create();
        dialog.show();

        Button b = dialog.getButton(DialogInterface.BUTTON_NEGATIVE);

        if(b != null) {
            b.setBackgroundDrawable(getResources().getDrawable(R.drawable.values));
//            b.setTextColor(parseColor("#fffff"));


        }




    }

    public void withEditText(View view) {


    }
}
